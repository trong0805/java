
package assignment_trongtdph17510;

public class NhanVien{
    String HoTen;
    String maNV;
    Double luong;
    
    @Override
    public String toString() {
        return "NhanVien{" + "HoTen=" + HoTen + ", maNV=" + maNV + ", luong=" + luong + '}';
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public Double getLuong() {
        return luong;
    }

    public void setLuong(Double luong) {
        this.luong = luong;
    }
    public Double getThuNhap(){
       
        return luong ;
    }
    public Double getThueThuNhap(){
        Double tn = getThuNhap();
        Double pt = 0.0;
        if(tn > 9 && tn < 15){
            pt = 0.1;
        }else if(tn>15){
            pt = 0.12;
        }
        return tn*pt;
    }
    public NhanVien(String HoTen, String maNV, Double luong) {
        this.HoTen = HoTen;
        this.maNV = maNV;
        this.luong = luong;
    }
}

