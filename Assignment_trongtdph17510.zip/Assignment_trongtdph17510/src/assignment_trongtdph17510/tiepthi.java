/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_trongtdph17510;

/**
 *
 * @author HP
 */
public class tiepthi extends NhanVien{
    Double danhso;
    Double huehong;

    public tiepthi(Double danhso, Double huehong, String HoTen, String maNV, Double luong) {
        super(HoTen, maNV, luong);
        this.danhso = danhso;
        this.huehong = huehong;
    }
    @Override
    public String toString() {
        super.toString();
        return "tiepthi{"+ "HoTen=" + HoTen + ", maNV=" + maNV + ", luong=" + luong + ", danhso=" + danhso + ", huehong=" + huehong + '}';
    }
}
