
package assignment_trongtdph17510;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.Comparator;
import java.util.Collections;

public class QlNhanVien {

    static Scanner sc = new Scanner(System.in);
    ArrayList<NhanVien> listNV = new ArrayList<NhanVien>();

    public void menu() {
//        listNV.add(new NhanVien("1", "1", 1.0));
//        listNV.add(new NhanVien("7", "7", 7.0));
//        listNV.add(new truongphong(3.0, "3", "3", 3.0));
//        listNV.add(new NhanVien("4", "4", 4.0));
//        listNV.add(new NhanVien("5", "5", 5.0));
//        listNV.add(new NhanVien("12", "1", 1.0));
//        listNV.add(new truongphong(55.0, "35", "35", 55.0));
//        listNV.add(new NhanVien("32", "32", 32.0));
//        listNV.add(new NhanVien("42", "42", 42.0));
//        listNV.add(new tiepthi(52.0,52.0,"52", "52", 52.0));
        while (true) {
            System.out.println("1. Nhập danh sách nhân viên từ bàn phím.");
            System.out.println("2. Xuất danh sách nhân viên ra màn hình.");
            System.out.println("3. Tìm và hiển thị nhân viên theo mã nhập từ bàn phím.");
            System.out.println("4. Xóa nhân viên theo mã nhập từ bàn phím.");
            System.out.println("5. Cập nhật thông tin nhân viên theo mã nhập từ bàn phím");
            System.out.println("6. Tìm các nhân viên theo khoảng lương nhập từ bàn phím.");
            System.out.println("7. Sắp xếp nhân viên theo họ và tên.");
            System.out.println("8. Sắp xếp nhân viên theo thu nhập.");
            System.out.println("9. Xuất 5 nhân viên có thu nhập cao nhất.");
            System.out.println("0. Thoát chương trình.");

            System.out.print("Mời nhập lựa chọn: ");
            int chon = Integer.parseInt(sc.nextLine());

            switch (chon) {
                case 1:
                    bai1();
                    break;
                case 2:
                    bai2();
                    break;
                case 3:
                    bai3();
                    break;
                case 4:
                    bai4();
                    break;
                case 5:
                    bai5();
                    break;
                case 6:
                    bai6();
                    break;
                case 7:
                    bai7();
                    break;
                case 8:
                    bai8();
                    break;
                case 9:
                    bai9();
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Mời chọn lại từ 0 --> 9 !");
                    break;
            }
        }
    }

    public void bai1() {
        while (true) {
            System.out.print("Mời nhập họ tên:");
            String HoTen = sc.nextLine();
            System.out.print("Mời nhập mã nhân viên:");
            String maNV = sc.nextLine();

            System.out.print("Mời nhập lương nhân viên:");
            Double luong = Double.parseDouble(sc.nextLine());
            
            System.out.println("1.nhân viên");
            System.out.println("2.trưởng phòng");
            System.out.println("3.tiếp thị");
            System.out.println("mời chọn:");
            int chuc = Integer.parseInt(sc.nextLine());

            switch (chuc) {
                case 1:
                    NhanVien nv = new NhanVien(HoTen, maNV, luong);
                    listNV.add(nv);
                    break;
                case 2:
                    System.out.println("nhập lương trách nhiệm:");
                    Double trachnhiem = Double.parseDouble(sc.nextLine());
                    truongphong tp = new truongphong(trachnhiem, HoTen, maNV, luong);
                    listNV.add(tp);
                    break;
                case 3:
                    System.out.println("Nhập doanh số:");
                    Double doanhso = Double.parseDouble(sc.nextLine());
                    System.out.println("Nhập huê hồng:");
                    Double huehong = Double.parseDouble(sc.nextLine());
                    tiepthi tt = new tiepthi(doanhso, huehong, HoTen, maNV, luong);
                    listNV.add(tt);
                    break;
            }

            System.out.print("Bạn có muốn nhập tiếp hay không ( y/n )");
            if (sc.nextLine().equals("n")) {
                break;
            }
        }
    }

    public void bai2() {
        System.out.println("XUẤT THÔNG TIN NHÂN VIÊN:");
        if (listNV.size() <= 0) {
            System.out.println("Danh sách rỗng mời nhập vào!");
        } else {
            for (NhanVien x : listNV) {
                System.out.println(x);
            }
        }
    }

    public void bai3() {
        System.out.print("Mời nhập mã nhân viên cần thông tin:");
        String maNV = sc.nextLine();

        for (NhanVien x : listNV) {
            if (x.getMaNV().equalsIgnoreCase(maNV)) {
                System.out.println(x);
            }
        }
    }

    public void bai4() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Mời nhập mã nhân viên cần xóa:");
        String ma = sc.nextLine();
        for (NhanVien x : listNV) {
            if (x.getMaNV().equalsIgnoreCase(ma)) {
                listNV.remove(x);
                break;
            }
        }
    }

    public void bai5() {
        int count = 0;
        System.out.print("Mời nhập mã nhân viên cần cập nhật thông tin:");
        String MaNV = sc.nextLine();

        for (NhanVien x : listNV) {
            if (x.getMaNV().equalsIgnoreCase(MaNV)) {
                System.out.println("Nhập tên mới:");
                String HoTen = sc.nextLine();
                System.out.println("Mời nhập mã NV mới:");
                String maNV = sc.nextLine();
                System.out.println("MỜi nhập lương mới:");
                Double luong = Double.parseDouble(sc.nextLine());

                listNV.set(count, new NhanVien(HoTen, maNV, luong));
                break;
            }
            count++;
        }
        System.out.println(listNV);
    }

    public void bai6() {
        System.out.println("Mời nhập số lương cần tìm: ");
        Double luong = Double.parseDouble(sc.nextLine());

        for (NhanVien x : listNV) {
            if (x.getLuong().equals(luong)) {
                System.out.println(x);
            }
        }
    }

    public void bai7() {
        Collections.sort(listNV, (n1, n2) -> n1.getHoTen().compareTo(n2.getHoTen()));
        for (NhanVien x : listNV) {
            System.out.println(x);
        }
    }

    public void bai8() {
        Collections.sort(listNV, (n1, n2) -> Double.compare(n1.getThuNhap(), n2.getThuNhap()));
        for (NhanVien x : listNV) {
            System.out.println(x);
        }
    }

    public void bai9() {
        for(int i = 0; i < 5;i++){
            Collections.sort(listNV, (n1, n2) -> Double.compare(n2.getThuNhap(), n1.getThuNhap()));
            System.out.println(listNV.get(i));
        }
        
//            for (int i = 0; i <  5; i++) {
//                Collections.sort(listNV, (n2 ,  n1) -> Double.compare(n2.getThuNhap(), n1.getThuNhap()));
//                for(NhanVien x : listNV){
//                    System.out.println(x);
//                   
//                }
//            } 
        }

    
}
